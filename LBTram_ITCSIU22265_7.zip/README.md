# Student Management System

A simple Java web application built with **JSP**, **Servlets**, **DAO**, and **JDBC** following the **MVC architecture**. The system allows CRUD operations for students and courses.

---

## Setup Instructions

### Prerequisites

• JDK 21 installed
• NetBeans IDE (17.0 or later)
• Apache Tomcat (10.1 or later)
• MySQL Server (8.0 or later)
• MySQL Connector/J (JDBC driver)
• Basic knowledge of Java, HTML, and SQL

### ⚙Database Setup

1. **Create a database:**

```sql
CREATE DATABASE studentdb;
USE studentdb;

2. **Create tables and insert sample data:**
-- Table: courses
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(20),
    description TEXT,
    credits INT
);

-- Sample course
INSERT INTO course (name, code, description, credits)
VALUES 
('Computer Science', 'CS101', 'Intro to Computer Science', 3),
('Information Technology', 'IT101', 'Intro to IT', 3),
('Software Engineering', 'SE101', 'Intro to Software Engineering', 3);

-- Table: students
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    course_id INT,
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES course(id)
);

-- Sample students
INSERT INTO students (name, email, course_id)
VALUES 
('John Doe', 'john@example.com', (SELECT id FROM course WHERE name = 'Computer Science')),
('Jane Smith', 'jane@example.com', (SELECT id FROM course WHERE name = 'Information Technology')),
('Mike Johnson', 'mike@example.com', (SELECT id FROM course WHERE name = 'Software Engineering'));

3. **Update DB config in DBUtil.java:**-
private static final String URL = "jdbc:mysql://localhost:3306/studentdb";
private static final String USER = "your_mysql_username";
private static final String PASSWORD = "your_mysql_password";

## Features Implemented
Course Management
- Add, edit, delete, view courses
- Display course list
- Store code, name, description, credits

Student Management
- Add, edit, delete, view students
- Each student linked to a course
- Dropdown course selection in form
- View full student list with course name

Architecture
Follows MVC pattern:
- Model: Student, Course
- DAO: StudentDAO, CourseDAO
- Controller: StudentController, CourseServlet
- View: JSP files under /WEB-INF/views

Validations
- Form validations (required fields)
- Foreign key integrity enforced via DB
