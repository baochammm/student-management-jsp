package com.university.controller;

import com.university.dao.CourseDAO;
import com.university.model.Course;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "CourseServlet", urlPatterns = {"/courses", "/courses/*"})
public class CourseServlet extends HttpServlet {

    private CourseDAO courseDAO;

    @Override
    public void init() {
        courseDAO = new CourseDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathInfo = request.getPathInfo();

        if (pathInfo == null || pathInfo.equals("/")) {
            // Danh sách khóa học
            List<Course> courses = courseDAO.getAllCourses();
            request.setAttribute("courses", courses);
            request.getRequestDispatcher("/WEB-INF/views/course-list.jsp").forward(request, response);

        } else if (pathInfo.equals("/new")) {
            // Hiển thị form thêm mới
            request.setAttribute("course", new Course());
            request.setAttribute("formAction", "add");
            request.getRequestDispatcher("/WEB-INF/views/course-form.jsp").forward(request, response);

        } else if (pathInfo.startsWith("/edit/")) {
            // Form sửa khóa học
            int id = Integer.parseInt(pathInfo.substring("/edit/".length()));
            Course course = courseDAO.getCourseById(id);
            request.setAttribute("course", course);
            request.setAttribute("formAction", "update");
            request.getRequestDispatcher("/WEB-INF/views/course-form.jsp").forward(request, response);

        } else if (pathInfo.startsWith("/delete/")) {
            // Xóa khóa học
            int id = Integer.parseInt(pathInfo.substring("/delete/".length()));
            courseDAO.deleteCourse(id);
            response.sendRedirect(request.getContextPath() + "/courses");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pathInfo = request.getPathInfo();

        String code = request.getParameter("code");
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        int credits = Integer.parseInt(request.getParameter("credits"));

        if (pathInfo != null && pathInfo.equals("/add")) {
            Course course = new Course(code, name, description, credits);
            courseDAO.addCourse(course);
            response.sendRedirect(request.getContextPath() + "/courses");

        } else if (pathInfo != null && pathInfo.equals("/update")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Course course = new Course(id, code, name, description, credits);
            courseDAO.updateCourse(course);
            response.sendRedirect(request.getContextPath() + "/courses");
        }
    }
}
